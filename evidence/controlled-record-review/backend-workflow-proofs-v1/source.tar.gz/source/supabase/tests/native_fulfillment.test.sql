begin;create extension if not exists pgtap with schema extensions;set local search_path=public,extensions;select no_plan();
-- FIXTURE_BEGIN
insert into auth.users(id,email,raw_user_meta_data) values
 ('a5510000-0000-4000-8000-000000000001','native-rx-dvm@example.test','{}'),
 ('a5510000-0000-4000-8000-000000000002','native-rx-staff@example.test','{}'),
 ('a5510000-0000-4000-8000-000000000003','native-rx-uncommissioned@example.test','{}'),
 ('a5510000-0000-4000-8000-000000000004','native-rx-admin@example.test','{}');
update public.profiles set is_active = true where id in ('a5510000-0000-4000-8000-000000000001','a5510000-0000-4000-8000-000000000002','a5510000-0000-4000-8000-000000000003','a5510000-0000-4000-8000-000000000004');
insert into public.user_roles (user_id, role) values ('a5510000-0000-4000-8000-000000000001','STAFF'),('a5510000-0000-4000-8000-000000000002','STAFF'),('a5510000-0000-4000-8000-000000000003','STAFF'),('a5510000-0000-4000-8000-000000000004','STAFF');

update profiles set full_name='Synthetic prescriber' where id='a5510000-0000-4000-8000-000000000001';
insert into user_roles(user_id,role) values('a5510000-0000-4000-8000-000000000001','DVM'),('a5510000-0000-4000-8000-000000000001','ADMIN'),('a5510000-0000-4000-8000-000000000003','DVM'),('a5510000-0000-4000-8000-000000000004','ADMIN');
create temp table fx(k text primary key,id uuid);create temp table data(k text primary key,v jsonb);grant all on fx,data to authenticated;
set local role authenticated;select set_config('request.jwt.claims','{"sub":"a5510000-0000-4000-8000-000000000001","role":"authenticated"}',true);
insert into fx select 'client',id from save_client(auth.uid(),null,null,'Native','Household','+13035559015','fixture-9015@example.test','EMAIL','2619 Synthetic Street',null);
insert into fx select 'pet',id from save_patient(null,(select id from fx where k='client'),null,'Native Patient','Dog',null,null,'unknown',null,'unknown','unknown',null,null,null);
insert into fx select 'product',id from save_catalog_product(null,null,'Synthetic medication','medication','','tablet',100,true);
insert into fx select k,gen_random_uuid() from unnest(array['config','save','draft','sign','save2','draft2']) k;
insert into data values('config-request',jsonb_build_object('user_id',auth.uid(),'expected_version',null,'attest_review',true,'fields',jsonb_build_object('active',true,'license_number','SYNTHETIC','license_state','CO','license_expires_on','2099-12-31','practice_name','Synthetic practice','practice_address','2619 Synthetic Street','practice_phone',null,'clinical_review_note','Synthetic fixture only')));
insert into data select 'fields',jsonb_build_object('encounter_id',null,'medication',jsonb_build_object('name','Synthetic medication','strength','Synthetic strength','form','Synthetic form','directions','Synthetic directions only','route','Synthetic route'),'quantity_per_fill','30','unit','tablet','refills_authorized',2,'fulfillment_mode','practice_stock','product_id',(select id from fx where k='product'),'starts_on',(now() at time zone 'America/Denver')::date,'expires_on','2099-12-31');
insert into data select 'save-request',jsonb_build_object('draft_id',(select id from fx where k='draft'),'pet_id',(select id from fx where k='pet'),'client_id',(select id from fx where k='client'),'expected_version',null,'fields',v) from data where k='fields';
-- FIXTURE_END

insert into fx select k,gen_random_uuid() from unnest(array['invoice','dispense','dispense2','dispense3','close','close3','pickup','pickup2','refill','refill-create','refill-link']) k;
insert into fx values('lot1','b5510000-0000-4000-8000-000000000001'),('lot2','b5510000-0000-4000-8000-000000000002');
select configure_native_prescriber((select id from fx where k='config'),(select v from data where k='config-request'));
select save_native_prescription_draft((select id from fx where k='save'),(select v from data where k='save-request'));
insert into data select 'sign-request',jsonb_build_object('draft_id',(select id from fx where k='draft'),'pet_id',(select id from fx where k='pet'),'expected_version',1,'expected_context_hash',preview_native_prescription_sign((select id from fx where k='draft'),1)->>'context_hash','signature_name','Synthetic prescriber','attest_review',true);
insert into data select 'sign-receipt',sign_native_prescription((select id from fx where k='sign'),(select v from data where k='sign-request'));
select receive_inventory(gen_random_uuid(),(select id from fx where k='lot1'),(select id from fx where k='product'),'FULFILL-1',current_date+365,'Synthetic clinic',20,'Synthetic opening stock');
select receive_inventory(gen_random_uuid(),(select id from fx where k='lot2'),(select id from fx where k='product'),'FULFILL-2',current_date+365,'Synthetic clinic',100,'Synthetic opening stock');
select create_billing_invoice((select id from fx where k='invoice'),(select id from fx where k='client'));
select create_native_refill((select id from fx where k='refill-create'),jsonb_build_object('refill_id',(select id from fx where k='refill'),'pet_id',(select id from fx where k='pet'),'client_id',(select id from fx where k='client'),'medication_requested','Synthetic request','requester_note',null,'channel','phone','reason','Synthetic intake'));
select transition_native_refill((select id from fx where k='refill-link'),jsonb_build_object('refill_id',(select id from fx where k='refill'),'pet_id',(select id from fx where k='pet'),'expected_version',1,'action','link','reason','Exact order','assigned_to',null,'authorization_id',(select id from fx where k='sign'),'expected_link_context_hash',preview_native_refill_link((select id from fx where k='refill'),(select id from fx where k='pet'),(select id from fx where k='sign'))->>'context_hash'));
insert into data select 'target',jsonb_build_object('authorization_id',(select id from fx where k='sign'),'pet_id',(select id from fx where k='pet'),'slot_index',0,'expected_slot_version',null,'invoice_id',(select id from fx where k='invoice'),'quantity','10','allocations',jsonb_build_array(jsonb_build_object('lot_id',(select id from fx where k='lot1'),'quantity','4'),jsonb_build_object('lot_id',(select id from fx where k='lot2'),'quantity','6')),'refill',jsonb_build_object('id',(select id from fx where k='refill'),'expected_version',2));
select is(read_native_fulfillment((select id from fx where k='sign'),(select id from fx where k='pet'))#>>'{usage,remaining_quantity}','90.000','Initial allowance includes initial fill plus two refills');
select is(read_native_fulfillment((select id from fx where k='sign'),gen_random_uuid()),null::jsonb,'Wrong patient cannot read fulfillment');
insert into data select 'preview',preview_native_dispense(v) from data where k='target';
select is(read_native_fulfillment((select id from fx where k='sign'),(select id from fx where k='pet'))#>>'{usage,used_fill_slots}','0','Preview opens no slot');
select throws_ok($$select preview_native_dispense((select v||'{"quantity":"10.0001"}' from data where k='target'))$$,'23514','Invalid fulfillment quantity','Excess precision rejected before cast');
select throws_ok($$select preview_native_dispense((select jsonb_set(v,'{allocations}',jsonb_build_array(v#>'{allocations,1}',v#>'{allocations,0}')) from data where k='target'))$$,'23514','Sorted unique lot allocations required','Unsorted lots rejected');
select throws_ok($$select preview_native_dispense((select jsonb_set(v,'{allocations,1,lot_id}',v#>'{allocations,0,lot_id}') from data where k='target'))$$,'23514','Sorted unique lot allocations required','Duplicate lots rejected');
select throws_ok($$select preview_native_dispense((select v||'{"quantity":"11"}' from data where k='target'))$$,'23514','Lot allocations must exactly equal dispense quantity','Allocation sum exact');
select throws_ok($$select preview_native_dispense((select v||'{"slot_index":3}' from data where k='target'))$$,'23514','Authorized fill slot limit exceeded','Cannot exceed signed refill count');
select throws_ok($$select preview_native_dispense((select v||'{"slot_index":1}' from data where k='target'))$$,'PT409','Fill slot changed','Cannot skip initial slot');
insert into data select 'dispense-request',t.v||jsonb_build_object('expected_context_hash',p.v->>'context_hash','reason','Synthetic partial dispensing','attest_alert_review',true,'attest_dispense_review',true) from data t,data p where t.k='target' and p.k='preview';
-- A price change makes the entire reviewed transaction stale; no slot is opened.
select save_catalog_product((select id from fx where k='product'),1,'Synthetic medication','medication','','tablet',200,true);
select throws_ok($$select record_native_dispense((select id from fx where k='dispense'),(select v from data where k='dispense-request'))$$,'PT409','Fulfillment review context changed','Price drift requires renewed review');
select is(recover_native_fulfillment_operation((select id from fx where k='dispense')),null::jsonb,'Stale review leaves no receipt');
select is(read_native_fulfillment((select id from fx where k='sign'),(select id from fx where k='pet'))#>>'{usage,used_fill_slots}','0','Stale review leaves allowance untouched');
select save_catalog_product((select id from fx where k='product'),2,'Synthetic medication','medication','','tablet',100,true);
update data set v=preview_native_dispense((select v from data where k='target')) where k='preview';
update data set v=jsonb_set(v,'{expected_context_hash}',(select v->'context_hash' from data where k='preview')) where k='dispense-request';
insert into data select 'pre-fill-cancel',jsonb_build_object('authorization_id',(select id from fx where k='sign'),'pet_id',(select id from fx where k='pet'),'expected_event_id',null,'expected_context_hash',preview_native_prescription_cancel((select id from fx where k='sign'),(select id from fx where k='pet'))->>'context_hash','reason','Synthetic cancel','attest_review',true);
-- Fulfillment requires active staff, not prescriber commissioning.
reset role;delete from user_roles where user_id='a5510000-0000-4000-8000-000000000001' and role='DVM';set local role authenticated;
insert into data select 'dispense-receipt',record_native_dispense((select id from fx where k='dispense'),(select v from data where k='dispense-request'));
select is((select v#>>'{result,dispense,amount_cents}' from data where k='dispense-receipt'),'1000','Multi-lot event charges once for total quantity');
select is(jsonb_array_length((select v#>'{result,dispense,allocations}' from data where k='dispense-receipt')),2,'Both movement links frozen');
select is((select v#>>'{result,slot,remaining_quantity}' from data where k='dispense-receipt'),'20.000','Partial fill retains slot remainder');
select is((select v#>>'{result,refill_event,version}' from data where k='dispense-receipt'),'2','Dispense appends V2 refill event');
select is(read_native_refill((select id from fx where k='refill'),(select id from fx where k='pet'))#>>'{refill,state}','open','Dispensing does not claim pickup or close intake');
select is(record_native_dispense((select id from fx where k='dispense'),(select v from data where k='dispense-request')),(select v from data where k='dispense-receipt'),'Exact dispense retry creates no extra effects');
reset role;
select throws_ok($$update native_fill_slots set maximum_quantity=31 where authorization_id=(select id from fx where k='sign')$$,'23514','Native fill slot identity is immutable','Slot maximum cannot change');
select throws_ok($$update native_fill_slots set opened_by='a5510000-0000-4000-8000-000000000002' where authorization_id=(select id from fx where k='sign')$$,'23514','Native fill slot identity is immutable','Opening attribution immutable');
select throws_ok($$update native_fill_slots set version=version+2 where authorization_id=(select id from fx where k='sign')$$,'23514','Native fill slot progression is invalid','Slot revision cannot skip');
select throws_ok($$update native_fill_slots set version=version+1,dispensed_quantity=9,remaining_quantity=21 where authorization_id=(select id from fx where k='sign')$$,'23514','Native fill slot progression is invalid','Consumption cannot decrease');
select throws_ok($$update native_fill_slots set version=version+1 where authorization_id=(select id from fx where k='sign')$$,'23514','Unchanged consumption requires explicit forfeiture','No empty slot mutation');
select throws_ok($$delete from native_fill_slots where authorization_id=(select id from fx where k='sign')$$,'23514','Native fill slots cannot be deleted','Slot deletion denied');
set local role authenticated;

select is(recover_native_fulfillment_operation((select id from fx where k='dispense')),(select v from data where k='dispense-receipt'),'Exact receipt recovery');
select throws_ok($$select record_native_dispense((select id from fx where k='dispense'),(select v||'{"reason":"Changed"}' from data where k='dispense-request'))$$,'23514','Fulfillment operation identity cannot change','UUID payload immutable');
select throws_ok($$select record_native_dispense(gen_random_uuid(),(select v from data where k='dispense-request'))$$,'PT409','Fill slot changed','Second UUID cannot reopen slot');
select is(read_native_prescription_print((select id from fx where k='sign'),(select id from fx where k='dispense'))->'dispense',(select v#>'{result,dispense,artifact}' from data where k='dispense-receipt'),'Dispensed print is exact immutable artifact');
select throws_ok($$select read_native_prescription_print((select id from fx where k='sign'),gen_random_uuid())$$,'23514','Exact native authorization dispense required','Wrong dispense print refused');
reset role;insert into user_roles(user_id,role) values('a5510000-0000-4000-8000-000000000001','DVM');set local role authenticated;
select throws_ok($$select cancel_native_prescription(gen_random_uuid(),(select v from data where k='pre-fill-cancel'))$$,'PT409','Authorization change context changed','Intervening fill invalidates old cancellation review');
insert into data select 'close-request',jsonb_build_object('authorization_id',(select id from fx where k='sign'),'pet_id',(select id from fx where k='pet'),'slot_index',0,'expected_slot_version',1,'expected_context_hash',preview_native_slot_close((select id from fx where k='sign'),(select id from fx where k='pet'),0)->>'context_hash','reason','Explicitly forfeit undistributed remainder','attest_forfeit',true);
insert into data select 'close-receipt',close_native_fill_slot((select id from fx where k='close'),(select v from data where k='close-request'));
select is((select v#>>'{result,forfeited_quantity}' from data where k='close-receipt'),'20.000','Slot close records exact forfeiture');
reset role;
select throws_ok($$update native_fill_slots set version=version+1,state='open',remaining_quantity=20,closure_kind=null,closed_by=null,closed_at=null,close_reason=null where authorization_id=(select id from fx where k='sign') and slot_index=0$$,'23514','Native fill slot progression is invalid','Forfeited slot cannot reopen');
set local role authenticated;

select is(read_native_fulfillment((select id from fx where k='sign'),(select id from fx where k='pet'))#>>'{usage,remaining_quantity}','60.000','Forfeited remainder does not carry into next slot');
select is(close_native_fill_slot((select id from fx where k='close'),(select v from data where k='close-request')),(select v from data where k='close-receipt'),'Close exact retry');
insert into data select 'target2',v||jsonb_build_object('slot_index',1,'quantity','30','refill',null,'allocations',jsonb_build_array(jsonb_build_object('lot_id',(select id from fx where k='lot2'),'quantity','30'))) from data where k='target';
insert into data select 'request2',v||jsonb_build_object('expected_context_hash',preview_native_dispense(v)->>'context_hash','reason','Synthetic full second slot','attest_alert_review',true,'attest_dispense_review',true) from data where k='target2';
insert into data select 'receipt2',record_native_dispense((select id from fx where k='dispense2'),(select v from data where k='request2'));
select is((select v#>>'{result,slot,closure_kind}' from data where k='receipt2'),'filled','Full quantity automatically closes slot');
insert into data select 'target3',v||jsonb_build_object('slot_index',2,'quantity','5','allocations',jsonb_build_array(jsonb_build_object('lot_id',(select id from fx where k='lot2'),'quantity','5'))) from data where k='target2';
insert into data select 'request3',v||jsonb_build_object('expected_context_hash',preview_native_dispense(v)->>'context_hash','reason','Synthetic last partial slot','attest_alert_review',true,'attest_dispense_review',true) from data where k='target3';
insert into data select 'receipt3',record_native_dispense((select id from fx where k='dispense3'),(select v from data where k='request3'));
select is(read_native_fulfillment((select id from fx where k='sign'),(select id from fx where k='pet'))#>>'{usage,dispensed_quantity}','45.000','Usage sums actual events across slots');
select is(read_native_fulfillment((select id from fx where k='sign'),(select id from fx where k='pet'))#>>'{usage,unopened_fill_slots}','0','All signed slots consumed');
insert into data select 'history',list_native_dispenses((select id from fx where k='sign'),(select id from fx where k='pet'),null,null,2);
select ok((select(v->>'has_more')::boolean from data where k='history'),'Dispense history sentinel');
select is((select jsonb_array_length(list_native_dispenses((select id from fx where k='sign'),(select id from fx where k='pet'),(v#>>'{next_cursor,before_at}')::timestamptz,(v#>>'{next_cursor,before_id}')::uuid,2)->'dispenses') from data where k='history'),1,'Dispense keyset preserves older event');
select is(jsonb_array_length(list_native_fill_slots((select id from fx where k='sign'),(select id from fx where k='pet'),0,2)->'slots'),2,'Slot index cursor');
select throws_ok($$select list_native_dispenses((select id from fx where k='sign'),(select id from fx where k='pet'),now(),null)$$,'23514','Invalid refill cursor','Half history cursor rejected');
select cancel_native_prescription(gen_random_uuid(),jsonb_build_object('authorization_id',(select id from fx where k='sign'),'pet_id',(select id from fx where k='pet'),'expected_event_id',null,'expected_context_hash',preview_native_prescription_cancel((select id from fx where k='sign'),(select id from fx where k='pet'))->>'context_hash','reason','Stop further fulfillment','attest_review',true));
select throws_ok($$select preview_native_dispense((select v||'{"expected_slot_version":1}' from data where k='target3'))$$,'23514','Active practice-stock authorization required','Cancellation stops all future dispensing');
select is(record_native_dispense((select id from fx where k='dispense'),(select v from data where k='dispense-request')),(select v from data where k='dispense-receipt'),'Historical exact retry survives cancellation');
select is(read_native_prescription_print((select id from fx where k='sign'),(select id from fx where k='dispense'))#>>'{status,state}','cancelled','Historical label includes current cancellation warning');
insert into data select 'close3',jsonb_build_object('authorization_id',(select id from fx where k='sign'),'pet_id',(select id from fx where k='pet'),'slot_index',2,'expected_slot_version',1,'expected_context_hash',preview_native_slot_close((select id from fx where k='sign'),(select id from fx where k='pet'),2)->>'context_hash','reason','Historical remainder forfeited','attest_forfeit',true);
select close_native_fill_slot((select id from fx where k='close3'),(select v from data where k='close3'));
select is(read_native_fulfillment((select id from fx where k='sign'),(select id from fx where k='pet'))#>>'{usage,forfeited_quantity}','45.000','Historical slot may close after cancellation');
insert into data select 'pickup-request',jsonb_build_object('authorization_id',(select id from fx where k='sign'),'pet_id',(select id from fx where k='pet'),'dispense_id',(select id from fx where k='dispense'),'expected_context_hash',preview_native_pickup((select id from fx where k='dispense'),(select id from fx where k='pet'),jsonb_build_object('id',(select id from fx where k='refill'),'expected_version',3,'reason','Client received prepared package'))->>'context_hash','recipient_name','Synthetic owner','recipient_relationship','Owner','reason','Recorded historical handoff','attest_handoff',true,'refill_close',jsonb_build_object('id',(select id from fx where k='refill'),'expected_version',3,'reason','Client received prepared package'));
-- Already accepted spelling must remain accepted; the original payload stays
-- byte-for-byte JSONB-identical for retries while native documents use UUIDs.
update data set v=v||jsonb_build_object('authorization_id',upper(v->>'authorization_id'),'pet_id',upper(v->>'pet_id'),'dispense_id',upper(v->>'dispense_id'))where k='pickup-request';
insert into data select 'pickup-receipt',record_native_pickup((select id from fx where k='pickup'),(select v from data where k='pickup-request'));
select is(read_native_refill((select id from fx where k='refill'),(select id from fx where k='pet'))#>>'{refill,state}','closed','Pickup may explicitly close its original linked intake');
select is(record_native_pickup((select id from fx where k='pickup'),(select v from data where k='pickup-request')),(select v from data where k='pickup-receipt'),'Exact pickup retry preserves accepted uppercase request UUIDs');
select throws_ok($$select record_native_pickup(gen_random_uuid(),(select v from data where k='pickup-request'))$$,'23514','Dispense pickup already acknowledged','Different pickup UUID cannot acknowledge twice');
select is(jsonb_array_length(list_native_pickups((select id from fx where k='sign'),(select id from fx where k='pet'))->'pickups'),1,'Pickup history retained separately');
select is(jsonb_array_length(list_native_slot_closures((select id from fx where k='sign'),(select id from fx where k='pet'))->'closures'),2,'Explicit closure history retained');
select set_config('request.jwt.claims','{"sub":"a5510000-0000-4000-8000-000000000002","role":"authenticated"}',true);
select is(recover_native_fulfillment_operation((select id from fx where k='dispense')),null::jsonb,'Foreign actor cannot recover fulfillment');
select throws_ok($$select record_native_dispense((select id from fx where k='dispense'),(select v from data where k='dispense-request'))$$,'23514','Fulfillment operation identity cannot change','Foreign actor cannot reuse receipt UUID');
select throws_ok($$select * from native_dispenses$$,'42501',null,'No direct ledger reads');
reset role;
select is((select count(*) from billing_invoice_items where invoice_id=(select id from fx where k='invoice')),3::bigint,'Exactly one invoice line per dispense irrespective of lots');
select is((select sum(amount_cents) from billing_invoice_items where invoice_id=(select id from fx where k='invoice')),4500::numeric,'Charges equal actual dispensed quantity');
select is((select version from billing_invoices where id=(select id from fx where k='invoice')),4,'Invoice increments once per dispense, never pickup');
select is((select sum(quantity) from inventory_movements where lot_id in(select id from fx where k in ('lot1','lot2'))),75::numeric,'No pickup or closure stock side effects');
select is((select count(*) from native_dispense_allocations where dispense_id in(select id from fx where k in('dispense','dispense2','dispense3'))),4::bigint,'Exact immutable movement allocations');
select is((select count(*) from patient_treatments where pet_id=(select id from fx where k='pet')),0::bigint,'Take-home dispensing never fabricates administration');
select throws_ok($$update native_dispenses set document='{}' where id=(select id from fx where k='dispense')$$,'23514',null,'Privileged history mutation blocked');
select ok(not has_function_privilege('service_role','record_native_dispense(uuid,jsonb)','execute'),'Worker cannot dispense');
select ok(not has_function_privilege('authenticated','native_fulfillment_finish(uuid,text,jsonb,jsonb)','execute'),'Private receipt writer denied');
-- Force the shared source constraints before this fixture rolls back.
reset role;
-- A privileged future writer cannot attach an extra allocation to an older
-- immutable dispense receipt, even with genuine current entry admission.
select throws_ok($test$do $body$declare root uuid:=(select id from fx where k='dispense');who uuid;lot uuid:=gen_random_uuid();movement uuid:=gen_random_uuid();begin
 select actor_id into who from native_dispenses where id=root;
 update profiles set is_active=true where id=who;
 perform set_config('request.jwt.claims',jsonb_build_object('sub',who,'role','authenticated')::text,true);
 insert into inventory_lots(id,product_id,lot_number,expires_on,location,created_by)values(lot,(select id from fx where k='product'),'SYNTHETIC-FORGED-ALLOCATION',current_date+365,'Synthetic clinic',who);
 perform stock_writer_enter('record_native_dispense',root);
 insert into inventory_movements(id,lot_id,quantity,kind,reason,created_by)values(movement,lot,-0.001,'dispense','Synthetic forged allocation',who);
 insert into native_dispense_allocations values(gen_random_uuid(),root,lot,movement,0.001);
 set constraints stock_source_required immediate;
end$body$$test$,'23514','Canonical stock source does not match movement','Extra source links cannot borrow a saved dispense receipt');
select is((select count(*)::int from inventory_movements where reason='Synthetic forged allocation'),0,'Forged native allocation rolls back stock and source together');
set constraints stock_source_required immediate;
select is((select count(*)from stock_movement_sources where writer='record_native_dispense'),(select count(*)from native_dispense_allocations),'Every actual native allocation has one dispensing source');

-- Handoff provenance is separate from the earlier stock debit and remains exact
-- even when a later command shares an already admitted query packet.
select set_config('request.jwt.claims','{"sub":"a5510000-0000-4000-8000-000000000001","role":"authenticated"}',true);
set constraints all immediate;set constraints all deferred;
select is((select count(*)::int from stock_pickup_sources s join native_pickups p on p.id=s.event_id where p.dispense_id=(select id from fx where k='dispense')),1,'One original handoff has one immutable source');
select ok((select s.actor_id=p.actor_id from stock_pickup_sources s join native_pickups p on p.id=s.event_id where p.id=(select id from fx where k='pickup')),'Handoff source preserves actual recorder');
select throws_ok($test$do $body$declare source native_pickups;begin
 perform record_native_pickup((select id from fx where k='pickup'),(select v from data where k='pickup-request'));
 select * into source from native_pickups where id=(select id from fx where k='pickup');
 source.id:=gen_random_uuid();source.dispense_id:=(select id from fx where k='dispense2');
 insert into native_pickups select source.*;
end$body$$test$,'23514','Canonical handoff writer mismatch','A handoff cannot borrow another root admission in the same query packet');
select throws_ok($test$do $body$begin
 insert into stock_pickup_sources values(gen_random_uuid(),auth.uid());
 set constraints stock_handoff_required immediate;
end$body$$test$,'23514','Canonical handoff source required','Orphan reverse handoff source cannot commit');
select throws_ok($test$do $body$begin
 insert into native_fulfillment_operations(id,actor_id,operation,request,request_hash,result,created_at)
 select gen_random_uuid(),actor_id,operation,request,request_hash,result,created_at from native_fulfillment_operations where id=(select id from fx where k='pickup');
 set constraints stock_handoff_required immediate;
end$body$$test$,'23514','Canonical handoff source required','A receipt without its original handoff and source cannot commit');
select throws_ok($test$do $body$declare definition text;request jsonb;begin
 definition:=pg_get_functiondef('record_native_pickup(uuid,jsonb)'::regprocedure);
 execute replace(definition,' perform public.stock_writer_enter(''record_native_pickup'',p_id);','');
 request:=(select v from data where k='pickup-request')||jsonb_build_object('dispense_id',(select id from fx where k='dispense2'),'refill_close',null,
 'expected_context_hash',preview_native_pickup((select id from fx where k='dispense2'),(select id from fx where k='pet'),null)->>'context_hash');
 perform record_native_pickup(gen_random_uuid(),request);
end$body$$test$,'23514','Stock writer admission required','An old or uninstrumented pickup body cannot commit a handoff');
select is((select count(*)::int from native_pickups where dispense_id=(select id from fx where k='dispense2')),0,'Rejected pickup leaves no physical handoff assertion');
select is((select count(*)::int from stock_pickup_sources),1,'Rejected pickup leaves no orphan audit link');
select throws_ok($$update stock_pickup_sources set actor_id=actor_id$$,'23514','Stock source evidence is immutable','Handoff recorder cannot be rewritten');
select throws_ok($$delete from stock_pickup_sources$$,'23514','Stock source evidence is immutable','Handoff provenance cannot be deleted');
select throws_ok($$truncate stock_pickup_sources$$,'23514','Stock source evidence is immutable','Handoff provenance cannot be truncated');

select * from finish();rollback;
