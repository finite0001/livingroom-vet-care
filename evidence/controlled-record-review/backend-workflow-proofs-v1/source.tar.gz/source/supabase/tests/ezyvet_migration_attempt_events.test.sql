begin;create extension if not exists pgtap with schema extensions;set local search_path=public,extensions;select no_plan();

-- Capture delivery baselines before any fixture actor or RPC. Preserve complete
-- preexisting rows, including same-count mutations, without clearing queues.
create function pg_temp.ezyvet_delivery_snapshot()returns jsonb language plpgsql volatile
set search_path=public,pg_temp set timezone='UTC' as $delivery$
declare relation_name text;fingerprint jsonb;result jsonb:='{}';begin
 foreach relation_name in array array['communication_outbox','messages','outbound_deliveries','outbound_message_attempts']loop
  execute format('select jsonb_build_object(''count'',count(*),''hash'',encode(sha256(convert_to(coalesce(jsonb_agg(to_jsonb(r)order by to_jsonb(r)::text),''[]''::jsonb)::text,''UTF8'')),''hex''))from public.%I r',relation_name)into fingerprint;
  result:=result||jsonb_build_object(relation_name,fingerprint);
 end loop;
 return result;
end$delivery$;
create temp table ezyvet_delivery_baseline as select pg_temp.ezyvet_delivery_snapshot()as value;


insert into auth.users(id,email,raw_user_meta_data) values('db700000-0000-4000-8000-000000000001','attachment-admin@example.test','{}'),('db700000-0000-4000-8000-000000000002','attachment-other@example.test','{}');
update public.profiles set is_active = true where id in ('db700000-0000-4000-8000-000000000001','db700000-0000-4000-8000-000000000002');
insert into public.user_roles (user_id, role) values ('db700000-0000-4000-8000-000000000001','STAFF'),('db700000-0000-4000-8000-000000000002','STAFF');

insert into user_roles(user_id,role) values('db700000-0000-4000-8000-000000000001','ADMIN'),('db700000-0000-4000-8000-000000000002','ADMIN');
create temp table fx(k text primary key,id uuid);create temp table data(k text primary key,v jsonb);grant all on fx,data to authenticated,service_role;
set local role authenticated;select set_config('request.jwt.claims','{"sub":"db700000-0000-4000-8000-000000000001","role":"authenticated"}',true);
insert into fx select 'client',id from save_client(auth.uid(),null,null,'Attachment','Owner','+13035550196','attachment@example.test','EMAIL',null,null);
insert into fx select 'pet',id from save_patient(null,(select id from fx where k='client'),null,'Metadata dog','Dog',null,null,'unknown',null,'unknown','unknown',null,null,null);
insert into fx select k,gen_random_uuid() from unnest(array['mapping','animal-run','run','run2','other-run']) k;
reset role;
insert into data select 'animal',to_jsonb(claim_ezyvet_import((select id from fx where k='animal-run'),'db700000-0000-4000-8000-000000000001','attachment-test-site','animal','https://api.trial.ezyvet.com'));
select stage_ezyvet_import_page((select id from fx where k='animal-run'),'db700000-0000-4000-8000-000000000001',(select(v->>'lease_id')::uuid from data where k='animal'),1,true,'[{"external_id":"77","payload":{"id":77}}]');
insert into ezyvet_record_links(id,request_id,request_hash,source_origin,source_site_uid,resource,external_id,snapshot_id,head_version,client_id,pet_id,local_version,action,reason,approved_by)
select (select id from fx where k='mapping'),gen_random_uuid(),'synthetic-approved-mapping',s.source_origin,s.source_site_uid,s.resource,s.external_id,s.id,h.version,(select id from fx where k='client'),(select id from fx where k='pet'),1,'link','Synthetic reviewed mapping','db700000-0000-4000-8000-000000000001' from ezyvet_import_snapshots s join ezyvet_identity_heads h on h.snapshot_id=s.id where s.resource='animal' and s.source_site_uid='attachment-test-site';
insert into data values('observation',jsonb_build_object('external_id','701','file_id','42','metadata',jsonb_build_object('id','701','file_id','42','record_type','Animal','record_id','77','name','Synthetic report','mime_type','application/pdf','notes',null),'raw_record_sha256',repeat('a',64),'stable_metadata_sha256',repeat('b',64),'file_sha256',null));
insert into data select 'page',jsonb_build_object('contract_version','ezyvet_animal_attachment_metadata_v1','parent',jsonb_build_object('record_type','Animal','record_id','77'),'page',1,'complete',true,'pagination',jsonb_build_object('items_page',1,'items_page_total',1,'items_page_size',10,'items_total',2),'observations',jsonb_build_array(v,jsonb_set(v,'{raw_record_sha256}',to_jsonb(repeat('c',64)))),'page_sha256',repeat('d',64)) from data where k='observation';
insert into data values('side-effects',jsonb_build_object('treatments',(select count(*) from patient_treatments),'invoices',(select count(*) from billing_invoices),'stock',(select count(*) from inventory_movements),'outbox',(select count(*) from communication_outbox),'objects',(select count(*) from storage.objects)));

insert into data select 'run',claim_ezyvet_attachment_import((select id from fx where k='run'),'db700000-0000-4000-8000-000000000001','attachment-test-site','https://api.trial.ezyvet.com',(select id from fx where k='mapping'));
select stage_ezyvet_attachment_page((select id from fx where k='run'),'db700000-0000-4000-8000-000000000001',(select(v->>'lease_id')::uuid from data where k='run'),(select v from data where k='page'));
update ezyvet_import_runs set retry_after=null where resource='attachment';
insert into fx select k,gen_random_uuid() from unnest(array['capture','capture2','capture3','capture4']) k;
insert into fx select 'attachment-snapshot',snapshot_id from ezyvet_attachment_page_observations where run_id=(select id from fx where k='run') and ordinal=1;

insert into fx select k,gen_random_uuid() from unnest(array['migration','scope','binding','rolled-back']) k;
insert into data select 'scope-input',jsonb_build_array(jsonb_build_object('id',(select id from fx where k='scope'),'mapping_id',m.id,'resource','attachment','parent_type','animal','parent_snapshot_id',m.snapshot_id,'parent_head_version',m.head_version,'disposition','required','reason','Synthetic retry history')) from ezyvet_record_links m where m.id=(select id from fx where k='mapping');
insert into data select 'first-claim',claim_ezyvet_attachment_import((select id from fx where k='run2'),'db700000-0000-4000-8000-000000000001','attachment-test-site','https://api.trial.ezyvet.com',(select id from fx where k='mapping'));
select is((select count(*)::integer from ezyvet_migration_attempt_events where child_run_id=(select id from fx where k='run2')),2,'Creation and first claim recorded before binding');
set local role authenticated;select set_config('request.jwt.claims','{"sub":"db700000-0000-4000-8000-000000000001","role":"authenticated"}',true);
select prepare_ezyvet_migration_run((select id from fx where k='migration'),'https://api.trial.ezyvet.com','attachment-test-site',(select v from data where k='scope-input'));
select bind_ezyvet_migration_child((select id from fx where k='binding'),(select id from fx where k='scope'),(select id from fx where k='run2'),'Observe existing attempt');
select is(read_ezyvet_migration_binding_progress((select id from fx where k='binding'))->>'version','2','Progress version describes durable history');
select is(read_ezyvet_migration_binding_progress((select id from fx where k='binding'))#>>'{attempt_history,complete_since_run_creation}','true','New run history begins at creation');
select is(read_ezyvet_migration_binding_progress((select id from fx where k='binding'))#>>'{attempt_history,claims}','1','First pre-binding claim counted once');
reset role;
select fail_ezyvet_import_page((select id from fx where k='run2'),'db700000-0000-4000-8000-000000000001',(select(v->>'lease_id')::uuid from data where k='first-claim'),'UPSTREAM_TIMEOUT',1);
select fail_ezyvet_import_page((select id from fx where k='run2'),'db700000-0000-4000-8000-000000000001',(select(v->>'lease_id')::uuid from data where k='first-claim'),'UPSTREAM_TIMEOUT',1);
select is((select count(*)::integer from ezyvet_migration_attempt_events where child_run_id=(select id from fx where k='run2') and kind='page_failed'),1,'Repeated failure acknowledgement records one event');
update ezyvet_import_runs set retry_after=null where id=(select id from fx where k='run2');
insert into data select 'second-claim',claim_ezyvet_attachment_import((select id from fx where k='run2'),'db700000-0000-4000-8000-000000000001','attachment-test-site','https://api.trial.ezyvet.com',(select id from fx where k='mapping'));
select is((select last_error_code from ezyvet_import_runs where id=(select id from fx where k='run2')),null::text,'Retry clears latest error as before');
select is((select error_code from ezyvet_migration_attempt_events where child_run_id=(select id from fx where k='run2') and kind='page_failed'),'UPSTREAM_TIMEOUT','Prior failure remains durable after retry');
select is((select count(distinct attempt_hash)::integer from ezyvet_migration_attempt_events where child_run_id=(select id from fx where k='run2') and kind='claimed'),2,'Two leases have distinct opaque attempt fingerprints');
select stage_ezyvet_attachment_page((select id from fx where k='run2'),'db700000-0000-4000-8000-000000000001',(select(v->>'lease_id')::uuid from data where k='second-claim'),(select v from data where k='page'));
select stage_ezyvet_attachment_page((select id from fx where k='run2'),'db700000-0000-4000-8000-000000000001',(select(v->>'lease_id')::uuid from data where k='second-claim'),(select v from data where k='page'));
select is((select count(*)::integer from ezyvet_migration_attempt_events where child_run_id=(select id from fx where k='run2')),5,'Exact staged-page replay does not duplicate history');
select is((select count(*)::integer from ezyvet_migration_attempt_events where child_run_id=(select id from fx where k='run2') and kind='page_staged'),1,'One committed page event');
select is((select attempt_hash from ezyvet_migration_attempt_events where child_run_id=(select id from fx where k='run2') and kind='page_staged'),encode(sha256(convert_to((select v->>'lease_id' from data where k='second-claim'),'UTF8')),'hex'),'Page event correlates to its successful attempt without raw token');
set local role authenticated;
insert into data select 'first-page',list_ezyvet_migration_attempt_events((select id from fx where k='binding'),null,2);
select is((select v#>>'{events,0,sequence}' from data where k='first-page'),'5','History ordered by per-run sequence');
select is((select v->>'has_more' from data where k='first-page'),'true','Attempt history uses bounded sentinel');
select is(list_ezyvet_migration_attempt_events((select id from fx where k='binding'),4,2)#>>'{events,0,kind}','page_failed','Cursor recovers prior failure after success');
select is(list_ezyvet_migration_attempt_events((select id from fx where k='binding'),2,2)#>>'{events,0,history_origin}','run_created','Last page exposes tracking origin');
select is(read_ezyvet_migration_binding_progress((select id from fx where k='binding'))#>>'{attempt_history,claims}','2','Progress counts both attempts');
select is(read_ezyvet_migration_binding_progress((select id from fx where k='binding'))#>>'{attempt_history,failed_pages}','1','Progress keeps failed page distinct from observations');
select is(read_ezyvet_migration_binding_progress((select id from fx where k='binding'))#>>'{attempt_history,staged_pages}','1','Progress counts committed staged page');
select throws_ok($$select * from ezyvet_migration_attempt_events$$,'42501',null,'Raw event table hidden');
select throws_ok($$select list_ezyvet_migration_attempt_events((select id from fx where k='binding'),0,20)$$,'23514',null,'Invalid sequence cursor rejected');
select throws_ok($$select list_ezyvet_migration_attempt_events((select id from fx where k='binding'),null,101)$$,'23514',null,'Unbounded history rejected');
select set_config('request.jwt.claims','{"sub":"db700000-0000-4000-8000-000000000002","role":"authenticated"}',true);
select throws_ok($$select list_ezyvet_migration_attempt_events((select id from fx where k='binding'))$$,'42501',null,'Other administrator cannot read attempt history');
reset role;
select throws_ok($$update ezyvet_migration_attempt_events set error_code='CHANGED'$$,'23514',null,'Event history cannot be rewritten');
select throws_ok($$delete from ezyvet_migration_attempt_events$$,'23514',null,'Event history cannot be deleted');
select ok(not has_function_privilege('service_role','list_ezyvet_migration_attempt_events(uuid,integer,integer)','EXECUTE'),'Service cannot use staff history RPC');
update ezyvet_import_runs set retry_after=null where resource='attachment';
select throws_ok($$do $x$begin perform claim_ezyvet_attachment_import((select id from fx where k='rolled-back'),'db700000-0000-4000-8000-000000000001','attachment-test-site','https://api.trial.ezyvet.com',(select id from fx where k='mapping'));raise exception 'Intentional rollback';end $x$;$$,'P0001','Intentional rollback','Source operation can roll back after event capture');
select is((select count(*)::integer from ezyvet_import_runs where id=(select id from fx where k='rolled-back')),0,'Rolled-back source run absent');
select is((select count(*)::integer from ezyvet_migration_attempt_events where child_run_id=(select id from fx where k='rolled-back')),0,'Rolled-back source operation leaves no audit event');
update profiles set is_active=false where id='db700000-0000-4000-8000-000000000001';
set local role authenticated;select set_config('request.jwt.claims','{"sub":"db700000-0000-4000-8000-000000000001","role":"authenticated"}',true);
select throws_ok($$select list_ezyvet_migration_attempt_events((select id from fx where k='binding'))$$,'42501',null,'Inactive owner cannot read history');
reset role;
select is(pg_temp.ezyvet_delivery_snapshot(),(select value from ezyvet_delivery_baseline),'Attempt capture sends no messages');
select * from finish();rollback;
