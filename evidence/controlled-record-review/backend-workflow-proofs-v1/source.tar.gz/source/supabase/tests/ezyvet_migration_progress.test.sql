begin;create extension if not exists pgtap with schema extensions;set local search_path=public,extensions;select no_plan();

-- Capture delivery baselines before any fixture actor or RPC. Preserve complete
-- preexisting rows, including same-count mutations, without clearing queues.
create function pg_temp.ezyvet_delivery_snapshot()returns jsonb language plpgsql volatile
set search_path=public,pg_temp set timezone='UTC' as $delivery$
declare relation_name text;fingerprint jsonb;result jsonb:='{}';begin
 foreach relation_name in array array['communication_outbox','messages','outbound_deliveries','outbound_message_attempts']loop
  execute format('select jsonb_build_object(''count'',count(*),''hash'',encode(sha256(convert_to(coalesce(jsonb_agg(to_jsonb(r)order by to_jsonb(r)::text),''[]''::jsonb)::text,''UTF8'')),''hex''))from public.%I r',relation_name)into fingerprint;
  result:=result||jsonb_build_object(relation_name,fingerprint);
 end loop;
 return result;
end$delivery$;
create temp table ezyvet_delivery_baseline as select pg_temp.ezyvet_delivery_snapshot()as value;


insert into auth.users(id,email,raw_user_meta_data) values('db700000-0000-4000-8000-000000000001','attachment-admin@example.test','{}'),('db700000-0000-4000-8000-000000000002','attachment-other@example.test','{}');
update public.profiles set is_active = true where id in ('db700000-0000-4000-8000-000000000001','db700000-0000-4000-8000-000000000002');
insert into public.user_roles (user_id, role) values ('db700000-0000-4000-8000-000000000001','STAFF'),('db700000-0000-4000-8000-000000000002','STAFF');

insert into user_roles(user_id,role) values('db700000-0000-4000-8000-000000000001','ADMIN'),('db700000-0000-4000-8000-000000000002','ADMIN');
create temp table fx(k text primary key,id uuid);create temp table data(k text primary key,v jsonb);grant all on fx,data to authenticated,service_role;
set local role authenticated;select set_config('request.jwt.claims','{"sub":"db700000-0000-4000-8000-000000000001","role":"authenticated"}',true);
insert into fx select 'client',id from save_client(auth.uid(),null,null,'Attachment','Owner','+13035550196','attachment@example.test','EMAIL',null,null);
insert into fx select 'pet',id from save_patient(null,(select id from fx where k='client'),null,'Metadata dog','Dog',null,null,'unknown',null,'unknown','unknown',null,null,null);
insert into fx select k,gen_random_uuid() from unnest(array['mapping','animal-run','run','run2','other-run']) k;
reset role;
insert into data select 'animal',to_jsonb(claim_ezyvet_import((select id from fx where k='animal-run'),'db700000-0000-4000-8000-000000000001','attachment-test-site','animal','https://api.trial.ezyvet.com'));
select stage_ezyvet_import_page((select id from fx where k='animal-run'),'db700000-0000-4000-8000-000000000001',(select(v->>'lease_id')::uuid from data where k='animal'),1,true,'[{"external_id":"77","payload":{"id":77}}]');
insert into ezyvet_record_links(id,request_id,request_hash,source_origin,source_site_uid,resource,external_id,snapshot_id,head_version,client_id,pet_id,local_version,action,reason,approved_by)
select (select id from fx where k='mapping'),gen_random_uuid(),'synthetic-approved-mapping',s.source_origin,s.source_site_uid,s.resource,s.external_id,s.id,h.version,(select id from fx where k='client'),(select id from fx where k='pet'),1,'link','Synthetic reviewed mapping','db700000-0000-4000-8000-000000000001' from ezyvet_import_snapshots s join ezyvet_identity_heads h on h.snapshot_id=s.id where s.resource='animal' and s.source_site_uid='attachment-test-site';
insert into data values('observation',jsonb_build_object('external_id','701','file_id','42','metadata',jsonb_build_object('id','701','file_id','42','record_type','Animal','record_id','77','name','Synthetic report','mime_type','application/pdf','notes',null),'raw_record_sha256',repeat('a',64),'stable_metadata_sha256',repeat('b',64),'file_sha256',null));
insert into data select 'page',jsonb_build_object('contract_version','ezyvet_animal_attachment_metadata_v1','parent',jsonb_build_object('record_type','Animal','record_id','77'),'page',1,'complete',true,'pagination',jsonb_build_object('items_page',1,'items_page_total',1,'items_page_size',10,'items_total',2),'observations',jsonb_build_array(v,jsonb_set(v,'{raw_record_sha256}',to_jsonb(repeat('c',64)))),'page_sha256',repeat('d',64)) from data where k='observation';
insert into data values('side-effects',jsonb_build_object('treatments',(select count(*) from patient_treatments),'invoices',(select count(*) from billing_invoices),'stock',(select count(*) from inventory_movements),'outbox',(select count(*) from communication_outbox),'objects',(select count(*) from storage.objects)));

insert into data select 'run',claim_ezyvet_attachment_import((select id from fx where k='run'),'db700000-0000-4000-8000-000000000001','attachment-test-site','https://api.trial.ezyvet.com',(select id from fx where k='mapping'));
select stage_ezyvet_attachment_page((select id from fx where k='run'),'db700000-0000-4000-8000-000000000001',(select(v->>'lease_id')::uuid from data where k='run'),(select v from data where k='page'));
update ezyvet_import_runs set retry_after=null where resource='attachment';
insert into fx select k,gen_random_uuid() from unnest(array['capture','capture2','capture3','capture4']) k;
insert into fx select 'attachment-snapshot',snapshot_id from ezyvet_attachment_page_observations where run_id=(select id from fx where k='run') and ordinal=1;

insert into fx select k,gen_random_uuid() from unnest(array['migration','scope','binding','replacement']) k;
insert into data select 'scope-input',jsonb_build_array(jsonb_build_object('id',(select id from fx where k='scope'),'mapping_id',m.id,'resource','attachment','parent_type','animal','parent_snapshot_id',m.snapshot_id,'parent_head_version',m.head_version,'disposition','required','reason','Explicit synthetic coverage')) from ezyvet_record_links m where m.id=(select id from fx where k='mapping');
set local role authenticated;select set_config('request.jwt.claims','{"sub":"db700000-0000-4000-8000-000000000001","role":"authenticated"}',true);
insert into data select 'manifest',prepare_ezyvet_migration_run((select id from fx where k='migration'),'https://api.trial.ezyvet.com','attachment-test-site',(select v from data where k='scope-input'));
select is((select v->>'scope_manifest_version' from data where k='manifest'),'1','Resolved scope digest has explicit version');
select ok((select v->>'scope_manifest_hash' ~ '^[a-f0-9]{64}$' from data where k='manifest'),'Resolved scope digest is SHA256');
select bind_ezyvet_migration_child((select id from fx where k='binding'),(select id from fx where k='scope'),(select id from fx where k='run'),'Existing synthetic run');
select is(read_ezyvet_migration_run((select id from fx where k='migration')),(select v from data where k='manifest'),'Binding does not change frozen scope digest');
insert into data select 'progress',read_ezyvet_migration_binding_progress((select id from fx where k='binding'));
select is((select v#>>'{observations,occurrences}' from data where k='progress'),'2','Duplicate page ordinals are two observations');
select is((select v#>>'{observations,distinct_source_identities}' from data where k='progress'),'1','Duplicate ordinals are one source identity');
select is((select v#>>'{observations,distinct_snapshot_versions}' from data where k='progress'),'1','Duplicate ordinals are one staged snapshot');
select is((select v#>>'{observations,exact_current_occurrences}' from data where k='progress'),'2','Exact current head validates both observed ordinals');
select is((select v#>>'{observations,occurrence_fidelity}' from data where k='progress'),'page_ordinal','Attachment observation fidelity declared');
select is((select v#>>'{scan,pages_observed}' from data where k='progress'),'1','Staged page count independent from item count');
select is((select v#>>'{scan,traversal_ended}' from data where k='progress'),'true','Review-ready run ended scan traversal');
select is((select v#>>'{scan,complete_coverage_verified}' from data where k='progress'),'false','Finished scan does not certify complete migration');
select is((select v#>'{scan,provider_total}' from data where k='progress'),'null'::jsonb,'Unknown provider total remains unknown');
select is((select v#>'{clinical_review,approved_local_outcomes}' from data where k='progress'),'null'::jsonb,'Observed source is not clinical approval');
select is((select v->>'attempt_history_available' from data where k='progress'),'true','Transactional attempt history remains available before binding');
select is((select v->>'parent_current' from data where k='progress'),'true','Exact saved parent is current');
select is((select v->>'household_current' from data where k='progress'),'true','Patient still belongs to selected household');
select set_config('request.jwt.claims','{"sub":"db700000-0000-4000-8000-000000000002","role":"authenticated"}',true);
select is(read_ezyvet_migration_binding_progress((select id from fx where k='binding')),null::jsonb,'Another administrator cannot read progress');
reset role;
select ok(not has_function_privilege('anon','read_ezyvet_migration_binding_progress(uuid)','EXECUTE'),'Anonymous progress access absent');
select ok(not has_function_privilege('service_role','read_ezyvet_migration_binding_progress(uuid)','EXECUTE'),'Service progress access absent');
select claim_ezyvet_attachment_import((select id from fx where k='run2'),'db700000-0000-4000-8000-000000000001','attachment-test-site','https://api.trial.ezyvet.com',(select id from fx where k='mapping'));
set local role authenticated;select set_config('request.jwt.claims','{"sub":"db700000-0000-4000-8000-000000000001","role":"authenticated"}',true);
select bind_ezyvet_migration_child((select id from fx where k='replacement'),(select id from fx where k='scope'),(select id from fx where k='run2'),'Explicit next attempt',(select id from fx where k='binding'));
select is(read_ezyvet_migration_binding_progress((select id from fx where k='binding'))->>'superseded','true','Earlier attempt is explicitly superseded');
select is(read_ezyvet_migration_binding_progress((select id from fx where k='replacement'))#>>'{observations,occurrences}','0','Unfetched child has zero known observations');
select is(read_ezyvet_migration_binding_progress((select id from fx where k='replacement'))#>>'{scan,traversal_ended}','false','Unfetched child has not finished traversal');
reset role;
update ezyvet_import_runs set status='page_limit_reached' where id=(select id from fx where k='run');
update ezyvet_identity_heads set version=version+1 where source_site_uid='attachment-test-site';
set local role authenticated;
select is(read_ezyvet_migration_binding_progress((select id from fx where k='binding'))#>>'{scan,page_limit_reached}','true','Page limit is an explicit blocker');
select is(read_ezyvet_migration_binding_progress((select id from fx where k='binding'))#>>'{scan,traversal_ended}','false','Page limit is not finished traversal');
select is(read_ezyvet_migration_binding_progress((select id from fx where k='binding'))->>'parent_current','false','Later parent head makes saved parent stale');
select is(read_ezyvet_migration_binding_progress((select id from fx where k='binding'))#>>'{observations,exact_current_occurrences}','0','Same snapshot at later head version is not exact current observation');
select is(read_ezyvet_migration_run((select id from fx where k='migration')),(select v from data where k='manifest'),'Mutable source and scan status do not alter scope digest');
reset role;
update ezyvet_import_runs set status='running',last_error_code='UPSTREAM_TIMEOUT',retry_after=now()+interval '1 minute' where id=(select id from fx where k='run');
set local role authenticated;
select is(read_ezyvet_migration_binding_progress((select id from fx where k='binding'))#>>'{scan,latest_error_code}','UPSTREAM_TIMEOUT','Latest failure remains distinct from observed records');
select is(read_ezyvet_migration_binding_progress((select id from fx where k='binding'))#>>'{observations,occurrences}','2','Failed retry does not erase earlier observations');
reset role;
update profiles set is_active=false where id='db700000-0000-4000-8000-000000000001';
set local role authenticated;
select throws_ok($$select read_ezyvet_migration_binding_progress((select id from fx where k='binding'))$$,'42501',null,'Inactive administrator cannot read progress');
reset role;
select is(pg_temp.ezyvet_delivery_snapshot(),(select value from ezyvet_delivery_baseline),'Progress and scope digest send no messages');
select * from finish();rollback;
