begin;create extension if not exists pgtap with schema extensions;set local search_path=public,extensions;select no_plan();

-- Capture delivery baselines before any fixture actor or RPC. Preserve complete
-- preexisting rows, including same-count mutations, without clearing queues.
create function pg_temp.ezyvet_delivery_snapshot()returns jsonb language plpgsql volatile
set search_path=public,pg_temp set timezone='UTC' as $delivery$
declare relation_name text;fingerprint jsonb;result jsonb:='{}';begin
 foreach relation_name in array array['communication_outbox','messages','outbound_deliveries','outbound_message_attempts']loop
  execute format('select jsonb_build_object(''count'',count(*),''hash'',encode(sha256(convert_to(coalesce(jsonb_agg(to_jsonb(r)order by to_jsonb(r)::text),''[]''::jsonb)::text,''UTF8'')),''hex''))from public.%I r',relation_name)into fingerprint;
  result:=result||jsonb_build_object(relation_name,fingerprint);
 end loop;
 return result;
end$delivery$;
create temp table ezyvet_delivery_baseline as select pg_temp.ezyvet_delivery_snapshot()as value;


insert into auth.users(id,email,raw_user_meta_data) values('db700000-0000-4000-8000-000000000001','attachment-admin@example.test','{}'),('db700000-0000-4000-8000-000000000002','attachment-other@example.test','{}');
update public.profiles set is_active = true where id in ('db700000-0000-4000-8000-000000000001','db700000-0000-4000-8000-000000000002');
insert into public.user_roles (user_id, role) values ('db700000-0000-4000-8000-000000000001','STAFF'),('db700000-0000-4000-8000-000000000002','STAFF');

insert into user_roles(user_id,role) values('db700000-0000-4000-8000-000000000001','ADMIN'),('db700000-0000-4000-8000-000000000002','ADMIN');
create temp table fx(k text primary key,id uuid);create temp table data(k text primary key,v jsonb);grant all on fx,data to authenticated,service_role;
set local role authenticated;select set_config('request.jwt.claims','{"sub":"db700000-0000-4000-8000-000000000001","role":"authenticated"}',true);
insert into fx select 'client',id from save_client(auth.uid(),null,null,'Attachment','Owner','+13035550196','attachment@example.test','EMAIL',null,null);
insert into fx select 'pet',id from save_patient(null,(select id from fx where k='client'),null,'Metadata dog','Dog',null,null,'unknown',null,'unknown','unknown',null,null,null);
insert into fx select k,gen_random_uuid() from unnest(array['mapping','animal-run','run','run2','other-run']) k;
reset role;
insert into data select 'animal',to_jsonb(claim_ezyvet_import((select id from fx where k='animal-run'),'db700000-0000-4000-8000-000000000001','attachment-test-site','animal','https://api.trial.ezyvet.com'));
select stage_ezyvet_import_page((select id from fx where k='animal-run'),'db700000-0000-4000-8000-000000000001',(select(v->>'lease_id')::uuid from data where k='animal'),1,true,'[{"external_id":"77","payload":{"id":77}}]');
insert into ezyvet_record_links(id,request_id,request_hash,source_origin,source_site_uid,resource,external_id,snapshot_id,head_version,client_id,pet_id,local_version,action,reason,approved_by)
select (select id from fx where k='mapping'),gen_random_uuid(),'synthetic-approved-mapping',s.source_origin,s.source_site_uid,s.resource,s.external_id,s.id,h.version,(select id from fx where k='client'),(select id from fx where k='pet'),1,'link','Synthetic reviewed mapping','db700000-0000-4000-8000-000000000001' from ezyvet_import_snapshots s join ezyvet_identity_heads h on h.snapshot_id=s.id where s.resource='animal' and s.source_site_uid='attachment-test-site';

insert into fx values('migration',gen_random_uuid());
insert into data select 'scope',jsonb_build_object('id',gen_random_uuid(),'mapping_id',m.id,'resource','attachment','parent_type','animal','parent_snapshot_id',m.snapshot_id,'parent_head_version',m.head_version,'disposition','required','reason','Synthetic supervised scope') from ezyvet_record_links m where m.id=(select id from fx where k='mapping');
insert into data select 'manifest',jsonb_build_array(v,v||jsonb_build_object('id',gen_random_uuid(),'resource','healthstatus','disposition','excluded','reason','Explicit pilot exclusion')) from data where k='scope';
set local role authenticated;
insert into data select 'saved',prepare_ezyvet_migration_run((select id from fx where k='migration'),'https://api.trial.ezyvet.com','attachment-test-site',(select v from data where k='manifest'));
select is((select jsonb_array_length(v->'scopes') from data where k='saved'),2,'Both required and excluded scope preserved');
select is((select v#>>'{run,actor_id}' from data where k='saved'),auth.uid()::text,'Actor is server derived');
select ok((select v#>>'{run,intent_hash}' ~ '^[a-f0-9]{64}$' from data where k='saved'),'Manifest has digest');
select is(prepare_ezyvet_migration_run((select id from fx where k='migration'),'https://api.trial.ezyvet.com','attachment-test-site',(select jsonb_build_array(v->1,v->0) from data where k='manifest')),(select v from data where k='saved'),'Reordered exact scopes recover same manifest');
select is(read_ezyvet_migration_run((select id from fx where k='migration')),(select v from data where k='saved'),'Server recovery returns immutable scope');
select is(jsonb_array_length(list_ezyvet_migration_runs()->'runs'),1,'Owner discovers saved run');
select is(list_ezyvet_migration_runs()->>'has_more','false','Final history page has no sentinel');
select throws_ok($$select prepare_ezyvet_migration_run((select id from fx where k='migration'),'https://api.trial.ezyvet.com','changed-site',(select v from data where k='manifest'))$$,'42501',null,'Changed UUID intent cannot replace saved request');
select throws_ok($$select prepare_ezyvet_migration_run(gen_random_uuid(),'https://untrusted.example','site','[]')$$,'23514',null,'Unknown source host rejected');
select throws_ok($$select prepare_ezyvet_migration_run(gen_random_uuid(),'https://api.trial.ezyvet.com','site','[]')$$,'23514',null,'Empty scope rejected');
select throws_ok($$select prepare_ezyvet_migration_run(gen_random_uuid(),'https://api.trial.ezyvet.com','site','{}')$$,'23514',null,'Nonarray scope rejected');
select throws_ok($$select prepare_ezyvet_migration_run(gen_random_uuid(),'https://api.trial.ezyvet.com','attachment-test-site',(select jsonb_build_array(v,v) from data where k='scope'))$$,'23514',null,'Duplicate scope UUID rejected');
select throws_ok($$select prepare_ezyvet_migration_run(gen_random_uuid(),'https://api.trial.ezyvet.com','attachment-test-site',(select jsonb_build_array(v||'{"actor_id":"unexpected"}') from data where k='scope'))$$,'23514',null,'Unknown actor field cannot spoof ownership');
select throws_ok($$select prepare_ezyvet_migration_run(gen_random_uuid(),'https://api.trial.ezyvet.com','attachment-test-site',(select jsonb_build_array(v||'{"parent_head_version":null}') from data where k='scope'))$$,'23514',null,'Null observed version rejected');
select throws_ok($$select prepare_ezyvet_migration_run(gen_random_uuid(),'https://api.trial.ezyvet.com','attachment-test-site',(select jsonb_build_array(v||'{"parent_type":"consult"}') from data where k='scope'))$$,'23514',null,'Unaccepted required attachment parent rejected');
select throws_ok($$select prepare_ezyvet_migration_run(gen_random_uuid(),'https://api.trial.ezyvet.com','different-site',(select v from data where k='manifest'))$$,'42501',null,'Cross-site mapping rejected');
select throws_ok($$select prepare_ezyvet_migration_run(gen_random_uuid(),'https://api.trial.ezyvet.com','attachment-test-site',(select jsonb_build_array(v||'{"id":"00000000-0000-4000-8000-000000000001"}',v||'{"id":"ffffffff-ffff-4fff-8fff-ffffffffffff","resource":"invalid"}') from data where k='scope'))$$,'23514',null,'Invalid later scope rolls back the already inserted valid scope');
select throws_ok($$select list_ezyvet_migration_runs(now(),null,20)$$,'23514',null,'Partial cursor rejected');
select throws_ok($$select list_ezyvet_migration_runs(null,null,101)$$,'23514',null,'Unbounded history rejected');
select throws_ok($$select * from ezyvet_migration_runs$$,'42501',null,'Direct manifest table hidden');
select throws_ok($$select * from ezyvet_migration_scopes$$,'42501',null,'Direct scope table hidden');
select set_config('request.jwt.claims','{"sub":"db700000-0000-4000-8000-000000000002","role":"authenticated"}',true);
select is(read_ezyvet_migration_run((select id from fx where k='migration')),null::jsonb,'Other administrator cannot recover owner scope');
select is(jsonb_array_length(list_ezyvet_migration_runs()->'runs'),0,'Other administrator history empty');
select throws_ok($$select prepare_ezyvet_migration_run((select id from fx where k='migration'),'https://api.trial.ezyvet.com','attachment-test-site',(select v from data where k='manifest'))$$,'42501',null,'Other administrator cannot claim same intent');
reset role;
select is((select count(*)::integer from ezyvet_migration_runs),1,'Invalid requests leave no partial runs');
select is((select count(*)::integer from ezyvet_migration_scopes),2,'Invalid requests leave no partial scope');
select throws_ok($$update ezyvet_migration_runs set source_site_uid='changed'$$,'23514',null,'Privileged update cannot rewrite run');
select throws_ok($$delete from ezyvet_migration_scopes$$,'23514',null,'Privileged delete cannot remove scope');
select ok(not has_table_privilege('service_role','ezyvet_migration_runs','INSERT'),'Service role has no direct insert');
select ok(not has_function_privilege('anon','read_ezyvet_migration_run(uuid)','EXECUTE'),'Anonymous RPC grant absent');
set local role authenticated;
select set_config('request.jwt.claims','{"sub":"db700000-0000-4000-8000-000000000001","role":"authenticated"}',true);
insert into data select 'saved-second',prepare_ezyvet_migration_run(gen_random_uuid(),'https://api.trial.ezyvet.com','attachment-test-site',(select jsonb_build_array(v||jsonb_build_object('id',gen_random_uuid())) from data where k='scope'));
insert into data select 'saved-third',prepare_ezyvet_migration_run(gen_random_uuid(),'https://api.trial.ezyvet.com','attachment-test-site',(select jsonb_build_array(v||jsonb_build_object('id',gen_random_uuid())) from data where k='scope'));
insert into data select 'page-one',list_ezyvet_migration_runs(null,null,2);
select is(jsonb_array_length((select v->'runs' from data where k='page-one')),2,'History respects requested page size');
select is((select v->>'has_more' from data where k='page-one'),'true','Extra history row is a sentinel');
select is((select v#>>'{runs,0,id}' from data where k='page-one'),(select v#>>'{run,id}' from data where k='saved-third'),'Newest manifest is first');
insert into data select 'page-two',list_ezyvet_migration_runs((v#>>'{runs,1,created_at}')::timestamptz,(v#>>'{runs,1,id}')::uuid,2) from data where k='page-one';
select is(jsonb_array_length((select v->'runs' from data where k='page-two')),1,'Cursor retrieves remaining manifest only');
select is((select v#>>'{runs,0,id}' from data where k='page-two'),(select id::text from fx where k='migration'),'Cursor does not skip the original saved manifest');
select is((select v->>'has_more' from data where k='page-two'),'false','Final bounded page clears sentinel');
reset role;
update ezyvet_identity_heads set version=version+1 where resource='animal' and source_site_uid='attachment-test-site';
set local role authenticated;
select set_config('request.jwt.claims','{"sub":"db700000-0000-4000-8000-000000000001","role":"authenticated"}',true);
select is(prepare_ezyvet_migration_run((select id from fx where k='migration'),'https://api.trial.ezyvet.com','attachment-test-site',(select v from data where k='manifest')),(select v from data where k='saved'),'Old exact intent recovers after source-head change');
select throws_ok($$select prepare_ezyvet_migration_run(gen_random_uuid(),'https://api.trial.ezyvet.com','attachment-test-site',(select jsonb_build_array(v||jsonb_build_object('id',gen_random_uuid())) from data where k='scope'))$$,'PT409',null,'New request must review changed parent version');
reset role;
update profiles set is_active=false where id='db700000-0000-4000-8000-000000000001';
set local role authenticated;
select throws_ok($$select read_ezyvet_migration_run((select id from fx where k='migration'))$$,'42501',null,'Inactive owner cannot recover');
select throws_ok($$select list_ezyvet_migration_runs()$$,'42501',null,'Inactive owner cannot list');
reset role;
select is((select count(*)::integer from ezyvet_import_runs),1,'Manifest creates no new provider run');
select is(pg_temp.ezyvet_delivery_snapshot(),(select value from ezyvet_delivery_baseline),'Manifest creates no outgoing messages');
select * from finish();rollback;
