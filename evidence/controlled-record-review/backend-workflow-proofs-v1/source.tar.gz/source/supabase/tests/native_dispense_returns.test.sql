begin;create extension if not exists pgtap with schema extensions;set local search_path=public,extensions;select no_plan();
-- FIXTURE_BEGIN
insert into auth.users(id,email,raw_user_meta_data) values
 ('a5510000-0000-4000-8000-000000000001','native-rx-dvm@example.test','{}'),
 ('a5510000-0000-4000-8000-000000000002','native-rx-staff@example.test','{}'),
 ('a5510000-0000-4000-8000-000000000003','native-rx-uncommissioned@example.test','{}'),
 ('a5510000-0000-4000-8000-000000000004','native-rx-admin@example.test','{}');
update public.profiles set is_active = true where id in ('a5510000-0000-4000-8000-000000000001','a5510000-0000-4000-8000-000000000002','a5510000-0000-4000-8000-000000000003','a5510000-0000-4000-8000-000000000004');
insert into public.user_roles (user_id, role) values ('a5510000-0000-4000-8000-000000000001','STAFF'),('a5510000-0000-4000-8000-000000000002','STAFF'),('a5510000-0000-4000-8000-000000000003','STAFF'),('a5510000-0000-4000-8000-000000000004','STAFF');

update profiles set full_name='Synthetic prescriber' where id='a5510000-0000-4000-8000-000000000001';
insert into user_roles(user_id,role) values('a5510000-0000-4000-8000-000000000001','DVM'),('a5510000-0000-4000-8000-000000000001','ADMIN'),('a5510000-0000-4000-8000-000000000003','DVM'),('a5510000-0000-4000-8000-000000000004','ADMIN');
create temp table fx(k text primary key,id uuid);create temp table data(k text primary key,v jsonb);grant all on fx,data to authenticated;
set local role authenticated;select set_config('request.jwt.claims','{"sub":"a5510000-0000-4000-8000-000000000001","role":"authenticated"}',true);
insert into fx select 'client',id from save_client(auth.uid(),null,null,'Native','Household','+13035550123','native-release@example.test','EMAIL','2619 Synthetic Street',null);
insert into fx select 'pet',id from save_patient(null,(select id from fx where k='client'),null,'Native Patient','Dog',null,null,'unknown',null,'unknown','unknown',null,null,null);
insert into fx select 'product',id from save_catalog_product(null,null,'Synthetic medication','medication','','tablet',100,true);
insert into fx select k,gen_random_uuid() from unnest(array['config','save','draft','sign','save2','draft2']) k;
insert into data values('config-request',jsonb_build_object('user_id',auth.uid(),'expected_version',null,'attest_review',true,'fields',jsonb_build_object('active',true,'license_number','SYNTHETIC','license_state','CO','license_expires_on','2099-12-31','practice_name','Synthetic practice','practice_address','2619 Synthetic Street','practice_phone',null,'clinical_review_note','Synthetic fixture only')));
insert into data select 'fields',jsonb_build_object('encounter_id',null,'medication',jsonb_build_object('name','Synthetic medication','strength','Synthetic strength','form','Synthetic form','directions','Synthetic directions only','route','Synthetic route'),'quantity_per_fill','30','unit','tablet','refills_authorized',2,'fulfillment_mode','practice_stock','product_id',(select id from fx where k='product'),'starts_on',(now() at time zone 'America/Denver')::date,'expires_on','2099-12-31');
insert into data select 'save-request',jsonb_build_object('draft_id',(select id from fx where k='draft'),'pet_id',(select id from fx where k='pet'),'client_id',(select id from fx where k='client'),'expected_version',null,'fields',v) from data where k='fields';
-- FIXTURE_END
select configure_native_prescriber((select id from fx where k='config'),(select v from data where k='config-request'));
select save_native_prescription_draft((select id from fx where k='save'),(select v from data where k='save-request'));
insert into data select 'sign-request',jsonb_build_object('draft_id',(select id from fx where k='draft'),'pet_id',(select id from fx where k='pet'),'expected_version',1,'expected_context_hash',preview_native_prescription_sign((select id from fx where k='draft'),1)->>'context_hash','signature_name','Synthetic prescriber','attest_review',true);
insert into data select 'sign-receipt',sign_native_prescription((select id from fx where k='sign'),(select v from data where k='sign-request'));
insert into fx select k,gen_random_uuid() from unnest(array['release','release-fill','release-pickup','release-cancel','stale','invoice','lot','dispense','pickup','cancel']) k;
create function pg_temp.preview_native_release(selection jsonb) returns jsonb language sql as $$select preview_record_release_v10((select id from fx where k='pet'),(select id from fx where k='client'),'EMAIL','native-release@example.test',selection)$$;
create function pg_temp.confirm_native_release(id uuid,selection jsonb,preview jsonb) returns public.record_releases language sql as $$select confirm_record_release(id,(select id from fx where k='pet'),(select id from fx where k='client'),'EMAIL','native-release@example.test',selection,preview->'snapshot',preview->>'source_hash',true)$$;
insert into data select 'selection',jsonb_build_object('native_prescription_ids',jsonb_build_array(id)) from fx where k='sign';
insert into data select 'preview',pg_temp.preview_native_release(v) from data where k='selection';
select receive_inventory(gen_random_uuid(),(select id from fx where k='lot'),(select id from fx where k='product'),'CORRECTION-TEST',current_date+365,'Synthetic clinic',100,'Synthetic opening stock');
insert into fx values('lot2',gen_random_uuid());
select receive_inventory(gen_random_uuid(),(select id from fx where k='lot2'),(select id from fx where k='product'),'RETURN-SECOND',current_date+365,'Synthetic clinic',100,'Synthetic stock');
select create_billing_invoice((select id from fx where k='invoice'),(select id from fx where k='client'));
insert into data select 'target',jsonb_build_object('authorization_id',(select id from fx where k='sign'),'pet_id',(select id from fx where k='pet'),'slot_index',0,'expected_slot_version',null,'invoice_id',(select id from fx where k='invoice'),'quantity','10','allocations',(select jsonb_agg(jsonb_build_object('lot_id',id,'quantity','5') order by id) from fx where k in('lot','lot2')),'refill',null);
insert into data select 'dispense',record_native_dispense((select id from fx where k='dispense'),v||jsonb_build_object('expected_context_hash',preview_native_dispense(v)->>'context_hash','reason','Synthetic dispensing','attest_alert_review',true,'attest_dispense_review',true)) from data where k='target';
reset role;
insert into fx select 'allocation1',id from native_dispense_allocations where dispense_id=(select id from fx where k='dispense') and lot_id=(select id from fx where k='lot');
insert into fx select 'allocation2',id from native_dispense_allocations where dispense_id=(select id from fx where k='dispense') and lot_id=(select id from fx where k='lot2');
insert into data select 'original',jsonb_build_object('dispense',(select document from native_dispenses where id=(select id from fx where k='dispense')),'usage',native_rx_usage_context((select id from fx where k='sign')),'items',(select jsonb_agg(to_jsonb(i) order by id) from billing_invoice_items i where invoice_id=(select id from fx where k='invoice')),'invoice',(select to_jsonb(i) from billing_invoices i where id=(select id from fx where k='invoice')));
insert into record_release_policy(id,enabled,accepted_schema_version,accepted_by,accepted_at,acceptance_reference) values(true,true,11,'Synthetic reviewer',now(),'TEST ONLY') on conflict(id) do update set enabled=true,accepted_schema_version=11,accepted_by=excluded.accepted_by,accepted_at=excluded.accepted_at,acceptance_reference=excluded.acceptance_reference;
set local role authenticated;
insert into data select 'fill-selection',jsonb_build_object('native_dispense_ids',jsonb_build_array(id)) from fx where k='dispense';
insert into data select 'preview11',preview_record_release_v11((select id from fx where k='pet'),(select id from fx where k='client'),'EMAIL','native-release@example.test',v) from data where k='fill-selection';
insert into data select 'release11',to_jsonb(pg_temp.confirm_native_release((select id from fx where k='release'),(select v from data where k='fill-selection'),(select v from data where k='preview11')));
insert into fx select k,gen_random_uuid() from unnest(array['intake','dispose','restock','policy','release12','intake2'])k;
create function pg_temp.return_intent(action text,intake_id uuid,qty1 text,qty2 text) returns jsonb language sql as $$select jsonb_build_object('target',jsonb_build_object('authorization_id',(select id from fx where k='sign'),'pet_id',(select id from fx where k='pet'),'dispense_id',(select id from fx where k='dispense')),'action',action,'intake_id',intake_id,'allocations',(select jsonb_agg(jsonb_build_object('allocation_id',id,'quantity',q) order by id) from(select id,case k when 'allocation1' then qty1 else qty2 end q from fx where k in('allocation1','allocation2')) a where q is not null),'custody',case when action='intake' then 'clinic_retained' else null end,'package_condition',case when action='intake' then 'sealed_intact' else null end,'storage_history',case when action='intake' then 'controlled' else null end,'reason','Synthetic return custody review','note','Synthetic client-shareable return evidence')$$;
create function pg_temp.return_request(intent jsonb) returns jsonb language sql as $$select jsonb_build_object('intent',intent,'expected_context_hash',p->>'context_hash','expected_head',p#>'{context,head}','attest_review',true,'attest_restock',intent->>'action'='restock') from(select preview_native_dispense_return(intent)p)q$$;
create function pg_temp.return_read() returns jsonb language sql as $$select read_native_dispense_returns((select id from fx where k='sign'),(select id from fx where k='pet'),(select id from fx where k='dispense'))$$;
create function pg_temp.release12() returns jsonb language sql as $$select preview_record_release_v12((select id from fx where k='pet'),(select id from fx where k='client'),'EMAIL','native-release@example.test',(select v from data where k='fill-selection'))$$;
select is(read_native_return_policy()->>'version','0','Uncommissioned policy version0');
select is(read_native_return_policy()->>'enabled','false','Restock disabled by default');
select is(read_native_return_policy()->'actor_id','null'::jsonb,'No fabricated policy reviewer');
select is(jsonb_array_length(pg_temp.return_read()->'allocations'),2,'Both original lots exposed with exact allocation identities');
select is(pg_temp.return_read()#>>'{head,version}','0','Empty return head');
select is(read_native_dispense_returns((select id from fx where k='sign'),gen_random_uuid(),(select id from fx where k='dispense')),null::jsonb,'Wrong patient cannot read returns');
select throws_ok($$select preview_native_dispense_return(pg_temp.return_intent('intake',null,'6',null))$$,'23514','Return exceeds original allocation remainder','Intake bounded by original allocation quantity');
select throws_ok($$select preview_native_dispense_return(pg_temp.return_intent('intake',null,'1.0001',null))$$,'23514',null,'Excess quantity precision rejected');
select throws_ok($$select preview_native_dispense_return(pg_temp.return_intent('intake',null,'1',null)||'{"unknown":true}')$$,'23514',null,'Closed intent enforced');
insert into data select 'intake-request',pg_temp.return_request(pg_temp.return_intent('intake',null,'2','3'));
insert into data select 'intake',record_native_dispense_return((select id from fx where k='intake'),v) from data where k='intake-request';
select is(jsonb_array_length((select v#>'{result,allocations}' from data where k='intake')),2,'Multi-lot physical intake recorded');
select is((select sum((x->>'held_quantity')::numeric)::text from jsonb_array_elements(pg_temp.return_read()->'allocations')x),'5.000','Intake is held custody');
select is(record_native_dispense_return((select id from fx where k='intake'),(select v from data where k='intake-request')),(select v from data where k='intake'),'Exact intake retry');
select throws_ok($$select record_native_dispense_return(gen_random_uuid(),(select v from data where k='intake-request'))$$,'23514','Return exceeds original allocation remainder','Different UUID stale intake cannot double count');
select throws_ok($$select record_native_dispense_return((select id from fx where k='intake'),(select jsonb_set(v,'{intent,note}','"Changed note"') from data where k='intake-request'))$$,'23514','Return identifier already used','Changed request rejected');
select is(read_record_release((select id from fx where k='release'))->>'eligible','false','Return intake invalidates old schema11');
select throws_ok($$select preview_record_release_v11((select id from fx where k='pet'),(select id from fx where k='client'),'EMAIL','native-release@example.test',(select v from data where k='fill-selection'))$$,'23514','Native return history requires release schema12','Schema11 cannot silently omit returns');
select throws_ok($$select pg_temp.preview_native_release((select v from data where k='fill-selection'))$$,'23514','Native return history requires release schema12','Schema10 cannot silently omit returns');
select throws_ok($$select read_native_prescription_print_v2((select id from fx where k='sign'),(select id from fx where k='dispense'))$$,'23514',null,'PrintV2 cannot omit custody');
select throws_ok($$select preview_native_pickup((select id from fx where k='dispense'),(select id from fx where k='pet'),null)$$,'23514','Dispense has return custody; use an attributed clarification instead of new original pickup','Original pickup cannot be invented after return custody');
select is(read_native_prescription_print_v3((select id from fx where k='sign'),(select id from fx where k='dispense'))#>>'{return_summary,event_count}','1','PrintV3 includes custody summary');
select is(read_native_return_intake((select id from fx where k='sign'),(select id from fx where k='pet'),(select id from fx where k='dispense'),(select id from fx where k='intake'))#>>'{intake,sequence}','1','Exact intake read supports disposition planning');
insert into data select 'dispose',record_native_dispense_return((select id from fx where k='dispose'),pg_temp.return_request(pg_temp.return_intent('dispose',(select id from fx where k='intake'),'1',null)));
select is((select sum((x->>'held_quantity')::numeric)::text from jsonb_array_elements(pg_temp.return_read()->'allocations')x),'4.000','Partial disposal reduces held custody');
select is((select sum((x->>'disposed_quantity')::numeric)::text from jsonb_array_elements(pg_temp.return_read()->'allocations')x),'1.000','Disposal is separately attributed');
reset role;
select is((select count(*)::int from inventory_movements where kind='native_return' and lot_id in(select id from fx where k in('lot','lot2'))),0,'Intake and disposal create no available-stock movement');
set local role authenticated;
insert into data select 'restock-intent',pg_temp.return_intent('restock',(select id from fx where k='intake'),'1','2');
select ok(preview_native_dispense_return((select v from data where k='restock-intent'))->'blockers' ? 'policy_disabled','Default policy blocks restock');
insert into data select 'disabled-restock-request',pg_temp.return_request(v) from data where k='restock-intent';
select throws_ok($$select record_native_dispense_return((select id from fx where k='restock'),(select v from data where k='disabled-restock-request'))$$,'42501','Restock is blocked by reviewed safeguards','Blocked preview cannot commit stock');
insert into data values('policy-request','{"expected_version":0,"enabled":true,"review_reference":"Synthetic clinical review only","attest_review":true}');
reset role;delete from user_roles where user_id='a5510000-0000-4000-8000-000000000001' and role='DVM';set local role authenticated;
select throws_ok($$select configure_native_return_policy((select id from fx where k='policy'),(select v from data where k='policy-request'))$$,'42501',null,'ADMIN alone cannot commission return policy');
select ok(preview_native_dispense_return((select v from data where k='restock-intent'))->'blockers' ? 'dvm_required','Restock preview shows DVM blocker');
reset role;insert into user_roles(user_id,role) values('a5510000-0000-4000-8000-000000000001','DVM');set local role authenticated;
insert into data select 'policy',configure_native_return_policy((select id from fx where k='policy'),v) from data where k='policy-request';
select is(configure_native_return_policy((select id from fx where k='policy'),(select v from data where k='policy-request')),(select v from data where k='policy'),'Policy exact UUID retry');
select is(recover_native_return_policy((select id from fx where k='policy')),(select v from data where k='policy'),'Policy recovery exact');
select throws_ok($$select record_native_dispense_return((select id from fx where k='restock'),(select v from data where k='disabled-restock-request'))$$,'PT409','Return review context changed','Policy update requires fresh restock review');
select save_catalog_product((select id from fx where k='product'),1,'Synthetic medication','medication','','tablet',100,false);
select ok(preview_native_dispense_return((select v from data where k='restock-intent'))->'blockers' ? 'product_inactive','Inactive catalog blocks available stock return');
select save_catalog_product((select id from fx where k='product'),2,'Synthetic medication','medication','','tablet',100,true);
-- Impossible metadata drift is synthetic and rolled back by the sentinel exception.
reset role;
select throws_ok($test$do $body$begin
 alter table catalog_products disable trigger inventory_guard;
 update catalog_products set unit='synthetic-changed-unit' where id=(select id from fx where k='product');
 alter table catalog_products enable trigger inventory_guard;
 if not (preview_native_dispense_return((select v from data where k='restock-intent'))->'blockers' ? 'unit_changed') then raise exception 'Missing unit blocker';end if;
 raise exception 'Observed unit blocker' using errcode='P0002';end$body$$test$,'P0002','Observed unit blocker','Changed unit prevents restock');
select is((select tgenabled::text from pg_trigger where tgrelid='catalog_products'::regclass and tgname='inventory_guard'),'O','Inventory guard restored after synthetic drift');
select throws_ok($test$do $body$declare s text;begin
 s:=pg_get_functiondef('public.preview_native_dispense_return(jsonb)'::regprocedure);
 s:=replace(s,'practice:=(clock_timestamp() at time zone ''America/Denver'')::date;','practice:=date ''2099-12-31'';');execute s;
 if not (preview_native_dispense_return((select v from data where k='restock-intent'))->'blockers' ? 'lot_expired') then raise exception 'Missing expiry blocker';end if;
 raise exception 'Observed expiry blocker' using errcode='P0002';end$body$$test$,'P0002','Observed expiry blocker','Expired original lots cannot enter available stock');
select throws_ok($test$do $body$declare s text;begin
 s:=pg_get_functiondef('public.native_return_policy_verified(integer)'::regprocedure);
 s:=replace(s,'return d.document;','return jsonb_set(d.document,''{reviewed_at}'',''"2099-12-31T00:00:00Z"''::jsonb);');execute s;
 perform record_native_dispense_return(gen_random_uuid(),pg_temp.return_request((select v from data where k='restock-intent')));
end$body$$test$,'PT409','Return observation clock moved backwards','Regressed event clock cannot predate policy review');
set local role authenticated;
select is(preview_native_dispense_return((select v from data where k='restock-intent'))->'allowed','true'::jsonb,'Reviewed retained sealed controlled quantities may restock');
insert into data select 'restock-request',pg_temp.return_request(v) from data where k='restock-intent';
insert into data select 'restock',record_native_dispense_return((select id from fx where k='restock'),v) from data where k='restock-request';
select is(record_native_dispense_return((select id from fx where k='restock'),(select v from data where k='restock-request')),(select v from data where k='restock'),'Restock exact retry never duplicates movements');
select is(recover_native_dispense_return((select id from fx where k='restock')),(select v from data where k='restock'),'Restock exact recovery returns frozen receipt');
select is(pg_temp.return_read()#>>'{head,version}','3','Intake disposal restock form one ordered chain');
select is((select sum((x->>'restocked_quantity')::numeric)::text from jsonb_array_elements(pg_temp.return_read()->'allocations')x),'3.000','Multi-lot restock totals exactly selected quantities');
select is((select sum((x->>'held_quantity')::numeric)::text from jsonb_array_elements(pg_temp.return_read()->'allocations')x),'1.000','Unselected intake quantity remains held');
select throws_ok($$select preview_native_dispense_return(pg_temp.return_intent('dispose',(select id from fx where k='intake'),'1',null))$$,'23514','Disposition exceeds intake held remainder','Spent intake allowance cannot be disposed again');
select throws_ok($$select preview_native_dispense_return(pg_temp.return_intent('intake',null,'4',null))$$,'23514','Return exceeds original allocation remainder','Restock never replenishes cumulative return allowance');
reset role;
set constraints all immediate;
select is((select count(*)::int from native_return_stock_links where event_id=(select id from fx where k='restock')),2,'Two original allocations link two positive movements');
select is((select sum(m.quantity)::text from native_return_stock_links l join inventory_movements m on m.id=l.movement_id where l.event_id=(select id from fx where k='restock')),'3.000','Available stock credited exactly three units');
select ok((select bool_and(m.kind='native_return' and m.created_at=e.created_at and m.created_by=e.actor_id) from native_return_stock_links l join inventory_movements m on m.id=l.movement_id join native_return_events e on e.id=l.event_id where e.id=(select id from fx where k='restock')),'Stock linkage stamps match immutable event');
select is(jsonb_build_object('dispense',(select document from native_dispenses where id=(select id from fx where k='dispense')),'usage',native_rx_usage_context((select id from fx where k='sign')),'items',(select jsonb_agg(to_jsonb(i) order by id) from billing_invoice_items i where invoice_id=(select id from fx where k='invoice')),'invoice',(select to_jsonb(i) from billing_invoices i where id=(select id from fx where k='invoice'))),(select v from data where k='original'),'Return leaves original dispense prescription allowance invoice and charge byte-identical');
set constraints all deferred;
set local role authenticated;
insert into data select 'preview12',pg_temp.release12();
select is((select v#>>'{snapshot,schema_version}' from data where k='preview12'),'12','New release captures explicit return disclosure');
select throws_ok($$select pg_temp.confirm_native_release((select id from fx where k='release12'),(select v from data where k='fill-selection'),(select v from data where k='preview12'))$$,'42501','Clinical acceptance of the release form and workflow is required before confirmation','Schema11 acceptance does not authorize schema12');
reset role;update record_release_policy set accepted_schema_version=12 where id;set local role authenticated;
insert into data select 'release12',to_jsonb(pg_temp.confirm_native_release((select id from fx where k='release12'),(select v from data where k='fill-selection'),(select v from data where k='preview12')));
insert into data select 'intake2-intent',pg_temp.return_intent('intake',null,'3','2')||'{"custody":"client_returned","package_condition":"opened","storage_history":"unknown"}'::jsonb;
insert into data select 'intake2',record_native_dispense_return((select id from fx where k='intake2'),pg_temp.return_request(v)) from data where k='intake2-intent';
select is((select sum((x->>'remaining_returnable_quantity')::numeric)::text from jsonb_array_elements(pg_temp.return_read()->'allocations')x),'0.000','Cumulative two-lot intake reaches original maximum');
select ok((preview_native_dispense_return(pg_temp.return_intent('restock',(select id from fx where k='intake2'),'1','1'))->'blockers') @> '["custody_not_retained","package_not_sealed","storage_not_controlled"]'::jsonb,'Client-returned opened unknown-storage custody cannot restock');
select throws_ok($$select preview_native_dispense_return(pg_temp.return_intent('intake',null,'0.001',null))$$,'23514','Return exceeds original allocation remainder','Cumulative cap rejects even fractional excess');
select is(jsonb_array_length(list_native_dispense_returns((select id from fx where k='sign'),(select id from fx where k='pet'),(select id from fx where k='dispense'),null,2)->'events'),2,'History bounded page');
select is(jsonb_array_length(list_native_dispense_returns((select id from fx where k='sign'),(select id from fx where k='pet'),(select id from fx where k='dispense'),3,2)->'events'),2,'History exclusive sequence cursor');
select configure_native_return_policy(gen_random_uuid(),'{"expected_version":1,"enabled":false,"review_reference":"Synthetic suspension","attest_review":true}');
select is(recover_native_dispense_return((select id from fx where k='restock')),(select v from data where k='restock'),'Policy suspension does not erase historical restock receipt');
select is(read_native_prescription_print_v3((select id from fx where k='sign'),(select id from fx where k='dispense'))#>>'{return_summary,event_count}','4','Print includes all return custody decisions');
select set_config('request.jwt.claims','{"sub":"a5510000-0000-4000-8000-000000000003","role":"authenticated"}',true);
select throws_ok($$select recover_native_dispense_return((select id from fx where k='restock'))$$,'42501','Return receipt unavailable','Another actor cannot recover an operation receipt');
reset role;
select ok(not has_table_privilege('authenticated','native_return_events','INSERT'),'Staff cannot forge return event');
select ok(not has_table_privilege('service_role','native_return_events','UPDATE'),'Service role cannot rewrite return history');
select ok(not has_table_privilege('service_role','native_return_stock_links','TRUNCATE'),'Service role cannot truncate stock linkage');
select throws_ok($$update native_return_events set action='dispose' where id=(select id from fx where k='intake')$$,'23514',null,'Original custody history immutable even to privileged fixture');
-- Deferred positive movement linkage is enforced even for privileged synthetic inserts.
-- Privileged fixture deliberately admits this statement so the ORIGINAL native
-- deferred constraint is still exercised beneath the new common admission guard.
select throws_ok($test$do $body$begin
 perform stock_writer_enter('record_native_dispense_return',gen_random_uuid());
 insert into inventory_movements(id,lot_id,quantity,kind,reason,created_by,created_at)
 values(gen_random_uuid(),(select id from fx where k='lot'),0.001,'native_return','Synthetic unlinked movement',auth.uid(),clock_timestamp());
 set constraints native_return_link_required immediate;
end$body$$test$,'23514','Native return stock linkage mismatch','Unlinked positive return movement cannot commit');
select is((select count(*)::int from inventory_movements where lot_id=(select id from fx where k='lot') and reason='Synthetic unlinked movement'),0,'Rejected deferred movement rolls back completely');
set local role authenticated;
select set_config('request.jwt.claims','{"sub":"a5510000-0000-4000-8000-000000000001","role":"authenticated"}',true);
-- Actual RPC history, not fabricated rows: 96 tiny dispositions bring the four-event chain to100.
do $body$begin for n in 1..96 loop
 perform record_native_dispense_return(gen_random_uuid(),pg_temp.return_request(pg_temp.return_intent('dispose',(select id from fx where k='intake2'),'0.001',null)));
end loop;end$body$;
select is(pg_temp.return_read()#>>'{head,version}','100','Actual immutable return chain reaches100');
select is(jsonb_array_length(read_native_prescription_print_v3((select id from fx where k='sign'),(select id from fx where k='dispense'))#>'{dispense_returns,events}'),100,'Print includes complete100-event disclosure');
select lives_ok($$select pg_temp.release12()$$,'Release supports complete100-event return disclosure');
select record_native_dispense_return(gen_random_uuid(),pg_temp.return_request(pg_temp.return_intent('dispose',(select id from fx where k='intake2'),'0.001',null)));
select is(pg_temp.return_read()#>>'{head,version}','101','Operational ledger continues beyond package boundary');
select throws_ok($$select read_native_prescription_print_v3((select id from fx where k='sign'),(select id from fx where k='dispense'))$$,'23514','More than100 return events; use complete paginated history instead of this package','Print refuses silently truncated101-event history');
select throws_ok($$select pg_temp.release12()$$,'23514','More than100 return events; use complete paginated history instead of this package','Release refuses silently truncated101-event history');
insert into data select 'boundary-page',list_native_dispense_returns((select id from fx where k='sign'),(select id from fx where k='pet'),(select id from fx where k='dispense'),null,100);
select is(jsonb_array_length((select v->'events' from data where k='boundary-page')),100,'First history page remains bounded100');
select is((select v->>'next_before_version' from data where k='boundary-page'),'2','History sentinel cursor preserves remaining event');
select is(jsonb_array_length(list_native_dispense_returns((select id from fx where k='sign'),(select id from fx where k='pet'),(select id from fx where k='dispense'),2,100)->'events'),1,'Second page retrieves final original event');
-- Force the shared source constraints before this fixture rolls back.
reset role;
set constraints stock_source_required immediate;
select is((select count(*)from stock_custody_sources where writer='record_native_dispense_return'),(select count(*)from native_return_events),'All actual v1 intake/disposal/restock custody events have source provenance');
select is((select count(*)from stock_movement_sources where writer='record_native_dispense_return'),(select count(*)from native_return_stock_links),'Each v1 stock return is linked once');
select * from finish();rollback;
